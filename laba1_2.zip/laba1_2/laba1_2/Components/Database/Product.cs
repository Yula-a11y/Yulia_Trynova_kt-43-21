﻿using System.ComponentModel.DataAnnotations;

namespace laba1_2.Components.Database
{
    public class Product
    {
        [Key]
        public int ProductId { get; set; }
        public int CategoryId { get; set; }
        public string? Name { get; set; }
        public decimal Price { get; set; }
        public string GetFormattedBasePrice() => Price.ToString("0.00");
    }
}
