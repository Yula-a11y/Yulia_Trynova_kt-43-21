﻿using Microsoft.EntityFrameworkCore;
using Microsoft.Extensions.Options;
using System;

namespace laba1_2.Components.Database
{
    public static class ProductsDbInit
    {
        public static async Task EnsureDbCreatedAndSeedAsync(DbContextOptions<MyDbContext> options)
        {
            //await MyDbContext.Database.MigrateAsync();

            //if (MyDbContext.Products.Any()) return;

            //await MyDbContext.AddRangeAsync(GetProducts());
            //await MyDbContext.SaveChangesAsync();
            var factory = new LoggerFactory();
            var builder = new DbContextOptionsBuilder<MyDbContext>(options)
                .UseLoggerFactory(factory);

            using var context = new MyDbContext(builder.Options);
            // result is true if the database had to be created
            if (await context.Database.EnsureCreatedAsync())
            {
                var seed = new SeedData();
                await seed.InitializeAsync(context);
            }

        }
        
    }
}
