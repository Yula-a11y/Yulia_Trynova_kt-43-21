﻿using System.ComponentModel.DataAnnotations;

namespace laba1_2.Components.Database
{
    public class Categories
    {
        [Key]
        public int CategoryId { get; set; }
        public string CategoryName { get; set; } = string.Empty;
    }
}
