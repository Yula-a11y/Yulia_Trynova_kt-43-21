﻿using System.Collections.Generic;
using Microsoft.EntityFrameworkCore;

namespace laba1_2.Components.Database
{
    public class MyDbContext : DbContext
    {
        public MyDbContext(DbContextOptions options) : base(options)
        {
        }

        protected override void OnModelCreating(ModelBuilder modelBuilder)
        {
            base.OnModelCreating(modelBuilder);
        }

        public DbSet<Product>? Products { get; set; }
        public DbSet<Categories>? Categories { get; set; }
        public DbSet<CategoryAssignment>? CategoryAssignments { get; set; }

        public override void Dispose()
        {
            base.Dispose();
        }


        public override ValueTask DisposeAsync()
        {
            return base.DisposeAsync();
        }
    }
}
