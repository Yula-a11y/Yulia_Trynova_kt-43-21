﻿namespace laba1_2.Components.Database
{
    public class SeedData
    {
        public async Task InitializeAsync(MyDbContext context)
        {
            // Проверка, если данные уже существуют в таблицах
            if (!context.Products.Any() && !context.Categories.Any())
            {
                var products = new Product[]
                {
                    new Product { ProductId=1, Name="Помидоры", Price=100.00M},
                    new Product { ProductId=2, Name="Огурцы", Price=90.00M},
                    new Product { ProductId=3, Name="Морковь", Price=70.00M},
                    new Product { ProductId=4, Name="Яблоки", Price=120.00M},
                    new Product { ProductId=5, Name="Бананы", Price=110.00M},
                    new Product { ProductId=6, Name="Киви", Price=150.00M},
                    new Product { ProductId=7, Name="Сок", Price=60.00M},
                    new Product { ProductId=8, Name="Вода", Price=30.00M},
                    new Product { ProductId=9, Name="Кофе", Price=300.00M},
                };

                var categories = new Categories[]
                {
                    new Categories { CategoryId=1, CategoryName="Овощи"},
                    new Categories { CategoryId=2, CategoryName="Фрукты"},
                    new Categories { CategoryId=3, CategoryName="Напитки"},
                };

                // Добавление данных в контекст
                context.Products.AddRange(products);
                context.Categories.AddRange(categories);

                // Сохранение данных в базе
                await context.SaveChangesAsync();
            }
        }
    }
}
