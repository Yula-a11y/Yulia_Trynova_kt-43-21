﻿namespace laba1_2.Components.Database
{
    public class CategoryAssignment
    {
        public int ID { get; set; }

        public int ProductID { get; set; }

        public int CategoryID { get; set; }

        public int Num { get; set; }
    }
}
